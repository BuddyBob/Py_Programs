from Sequence import sequence
seq = 6,11,18,27,38,51
sequence(seq)